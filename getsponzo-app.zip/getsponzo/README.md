# GetSponzo 🎯

**El marketplace de patrocinio con pago protegido por escrow y árbitro IA.**

[![Deploy](https://github.com/tu-usuario/getsponzo/actions/workflows/deploy.yml/badge.svg)](https://github.com/tu-usuario/getsponzo/actions)

## ¿Qué es GetSponzo?

GetSponzo conecta marcas con eventos, clubes deportivos y creadores de contenido. El diferenciador clave: el dinero queda retenido en custodia (escrow) hasta verificar el cumplimiento de cada hito. Si hay conflicto, una IA arbitra en 7 días.

## Características

- 🔍 **Explorar** — Marketplace con matches por IA
- ⚡ **Matches** — Sugerencias personalizadas
- 📝 **Contratos con escrow** — Pago por hitos verificados
- ⚖️ **Árbitro IA (Gemini)** — Resolución de disputas en 7 días
- 💬 **Chat seguro** — Bloqueo automático de datos de contacto
- ⭐ **Reputación verificada** — Historial público de cumplimiento

## Configuración

### 1. Instalar dependencias
```bash
npm install
```

### 2. Ejecutar en desarrollo
```bash
npm run dev
```

### 3. Configurar API Key de Gemini

Al entrar a la plataforma te pedirá tu API Key de Google Gemini (gratuita):
1. Ve a [aistudio.google.com](https://aistudio.google.com)
2. Crea una API Key gratis
3. Pégala en la pantalla de configuración

La key se guarda **solo en tu navegador** — nunca en ningún servidor.

## Deploy en GitHub Pages

El repositorio se despliega automáticamente en GitHub Pages cada vez que haces push a `main`.

URL: `https://tu-usuario.github.io/getsponzo/`

## Stack tecnológico

- **React 18** + **React Router 6**
- **Vite** (bundler)
- **Google Gemini API** (árbitro IA)
- **GitHub Actions** (CI/CD)
- **GitHub Pages** (hosting)

## Fundador

**Cristóbal Torretti** — Founder & CFO · Chile 🇨🇱  
ctorretti@miuandes.cl · [getsponzo.com](https://getsponzo.com)

---

*GetSponzo nació de la experiencia real de organizar eventos deportivos en Chile y entender que el acceso al patrocinio no debería depender de a quién conoces, sino del valor que eres capaz de crear.*
