// Hook para llamar a Google Gemini API (árbitro IA de disputas)
export async function callGeminiArbitration(apiKey, dispute) {
  const prompt = `Eres el árbitro imparcial de GetSponzo, un marketplace de patrocinio deportivo y cultural.

Analiza esta disputa entre un patrocinador y un patrocinado y decide qué porcentaje del pago en disputa debe liberarse al patrocinado.

DISPUTA:
Título: ${dispute.title}
Descripción del incumplimiento: ${dispute.description}
Evidencia del demandante: ${dispute.claimantEvidence}
Defensa del acusado: ${dispute.defendantEvidence || 'El acusado no presentó defensa dentro del plazo de 7 días.'}

INSTRUCCIONES:
- Analiza la evidencia de AMBAS partes de forma objetiva e imparcial
- Considera el nivel de cumplimiento del hito según la evidencia aportada
- SOLO puedes responder con uno de estos porcentajes: 0, 25, 50, 75 o 100
- 0% = incumplimiento total demostrado, el patrocinador recupera todo
- 25% = incumplimiento mayoritario con mínima ejecución
- 50% = responsabilidad compartida o cumplimiento parcial equitativo  
- 75% = cumplimiento mayoritario con falla menor justificada
- 100% = el patrocinado cumplió correctamente, liberar todo el pago

Responde ÚNICAMENTE en este formato JSON exacto, sin texto adicional:
{
  "verdict_pct": NÚMERO,
  "reasoning": [
    "Punto 1 del análisis",
    "Punto 2 del análisis", 
    "Punto 3 del análisis",
    "Resolución final con los montos"
  ]
}`

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 1024,
        },
      }),
    }
  )

  if (!response.ok) {
    const err = await response.json()
    throw new Error(err.error?.message || 'Error al llamar a Gemini')
  }

  const data = await response.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || ''

  // Parse JSON from response
  const jsonMatch = text.match(/\{[\s\S]*\}/)
  if (!jsonMatch) throw new Error('La IA no devolvió un formato válido')

  const result = JSON.parse(jsonMatch[0])
  return result
}
