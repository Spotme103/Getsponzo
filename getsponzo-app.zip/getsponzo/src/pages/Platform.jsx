import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Logo from '../components/Logo'
import Explore from '../components/Explore'
import Matches from '../components/Matches'
import Contracts from '../components/Contracts'
import Disputes from '../components/Disputes'
import Messages from '../components/Messages'
import Profile from '../components/Profile'

const TABS = [
  { id: 'explore', label: 'Explorar', icon: '🔍' },
  { id: 'matches', label: 'Matches', icon: '⚡' },
  { id: 'contracts', label: 'Contratos', icon: '📝' },
  { id: 'disputes', label: 'Disputas', icon: '⚖️' },
  { id: 'messages', label: 'Mensajes', icon: '💬' },
  { id: 'profile', label: 'Mi Perfil', icon: '⭐' },
]

export default function Platform({ apiKey, showToast, onClearKey }) {
  const navigate = useNavigate()
  const [nav, setNav] = useState('explore')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const goTo = (id) => { setNav(id); setMobileMenuOpen(false); window.scrollTo(0, 0) }

  const renderView = () => {
    switch (nav) {
      case 'explore': return <Explore showToast={showToast} goTo={goTo} />
      case 'matches': return <Matches showToast={showToast} goTo={goTo} />
      case 'contracts': return <Contracts showToast={showToast} goTo={goTo} />
      case 'disputes': return <Disputes apiKey={apiKey} showToast={showToast} />
      case 'messages': return <Messages showToast={showToast} />
      case 'profile': return <Profile showToast={showToast} onClearKey={onClearKey} />
      default: return <Explore showToast={showToast} goTo={goTo} />
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: '#08111f' }}>
      {/* Top nav */}
      <nav className="glass" style={{
        position: 'sticky', top: 0, zIndex: 100,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 4vw', borderBottom: '1px solid rgba(255,255,255,0.07)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => navigate('/')}>
          <Logo size={30} />
          <span style={{ fontFamily: 'Sora,sans-serif', fontWeight: 800, fontSize: 18 }}>
            Get<span style={{ color: '#17d4a0' }}>Sponzo</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#17d4a0', animation: 'pulse 2s infinite' }} />
          <span style={{ fontSize: 12, color: '#7795ad' }}>Árbitro IA activo</span>
          <button onClick={() => navigate('/')} className="btn-ghost" style={{ padding: '8px 16px', fontSize: 13, marginLeft: 8 }}>← Inicio</button>
        </div>
      </nav>

      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '24px 4vw 60px', display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 24 }}>
        {/* Sidebar desktop */}
        <aside className="hide-mobile" style={{ width: 200, position: 'sticky', top: 80, height: 'fit-content' }}>
          {TABS.map(({ id, label, icon }) => (
            <button key={id} onClick={() => goTo(id)} style={{
              display: 'flex', alignItems: 'center', gap: 11, width: '100%',
              padding: '11px 14px', borderRadius: 12, marginBottom: 4, fontSize: 14, fontWeight: 600,
              transition: 'all .2s', textAlign: 'left',
              background: nav === id ? 'rgba(23,212,160,.1)' : 'transparent',
              color: nav === id ? '#17d4a0' : '#7795ad',
              border: nav === id ? '1px solid rgba(23,212,160,.2)' : '1px solid transparent',
            }}>
              <span style={{ fontSize: 17 }}>{icon}</span>{label}
            </button>
          ))}
        </aside>

        {/* Mobile nav bar */}
        <div className="hide-desktop" style={{ gridColumn: '1/-1', display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4, marginBottom: 8 }}>
          {TABS.map(({ id, label, icon }) => (
            <button key={id} onClick={() => goTo(id)} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
              padding: '8px 14px', borderRadius: 11, fontSize: 11, fontWeight: 600,
              whiteSpace: 'nowrap', flexShrink: 0,
              background: nav === id ? 'rgba(23,212,160,.1)' : 'rgba(255,255,255,.03)',
              color: nav === id ? '#17d4a0' : '#7795ad',
              border: nav === id ? '1px solid rgba(23,212,160,.2)' : '1px solid rgba(255,255,255,.07)',
            }}>
              <span style={{ fontSize: 18 }}>{icon}</span>{label}
            </button>
          ))}
        </div>

        {/* Main content */}
        <main style={{ minWidth: 0 }}>
          {renderView()}
        </main>
      </div>
    </div>
  )
}
