import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Logo from '../components/Logo'
import InvestModal from '../components/InvestModal'

export default function Landing({ showToast }) {
  const navigate = useNavigate()
  const [investOpen, setInvestOpen] = useState(false)

  return (
    <div style={{ minHeight: '100vh', background: '#08111f' }}>
      {/* NAV */}
      <nav className="glass" style={{
        position: 'sticky', top: 0, zIndex: 100,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 5vw', borderBottom: '1px solid rgba(255,255,255,0.07)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
          <Logo size={34} />
          <span style={{ fontFamily: 'Sora,sans-serif', fontWeight: 800, fontSize: 20 }}>
            Get<span style={{ color: '#17d4a0' }}>Sponzo</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button onClick={() => setInvestOpen(true)} className="btn-ghost"
            style={{ padding: '9px 18px', fontSize: 13 }}>Invertir</button>
          <button onClick={() => navigate('/platform')} className="btn-primary"
            style={{ padding: '10px 20px', fontSize: 14 }}>Ver demo →</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ position: 'relative', padding: '80px 5vw 90px', textAlign: 'center', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse 80% 50% at 50% 0%, rgba(23,212,160,.1), transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(23,212,160,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(23,212,160,.03) 1px,transparent 1px)',
          backgroundSize: '60px 60px', animation: 'gridMove 10s linear infinite',
          pointerEvents: 'none',
          maskImage: 'radial-gradient(ellipse 70% 60% at 50% 30%, black, transparent)',
        }} />
        <div style={{ position: 'relative', maxWidth: 860, margin: '0 auto' }}>
          <div className="fade-up" style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'rgba(23,212,160,.08)', border: '1px solid rgba(23,212,160,.2)',
            borderRadius: 99, padding: '7px 16px', fontSize: 13, fontWeight: 600,
            color: '#17d4a0', marginBottom: 28,
          }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#17d4a0', animation: 'pulse 2s infinite' }} />
            Pago protegido por escrow + arbitraje con IA
          </div>
          <h1 className="fade-up-1" style={{
            fontSize: 'clamp(36px,6vw,66px)', fontWeight: 800,
            lineHeight: 1.06, marginBottom: 22,
          }}>
            El patrocinio,<br />
            <span style={{ background: 'linear-gradient(120deg,#17d4a0,#3df0bd)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              por fin protegido.
            </span>
          </h1>
          <p className="fade-up-2" style={{ fontSize: 'clamp(15px,2vw,19px)', color: '#7795ad', maxWidth: 580, margin: '0 auto 38px', lineHeight: 1.7 }}>
            Conecta marcas con eventos, clubes y creadores. El dinero queda retenido hasta verificar el cumplimiento. Si hay conflicto, la IA arbitra en <strong style={{ color: '#f0c64a' }}>7 días</strong>.
          </p>
          <div className="fade-up-3" style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => navigate('/platform')} className="btn-primary" style={{ fontSize: 16, padding: '14px 30px' }}>
              Probar la plataforma →
            </button>
            <button onClick={() => setInvestOpen(true)} className="btn-ghost" style={{ fontSize: 16, padding: '14px 30px' }}>
              Soy inversor
            </button>
          </div>
          {/* Stats */}
          <div style={{ display: 'flex', gap: 'clamp(20px,5vw,60px)', justifyContent: 'center', marginTop: 60, flexWrap: 'wrap' }}>
            {[['€1.967M', 'Mercado España 2024'], ['+19%', 'Crecimiento anual'], ['€445M', 'Mercado Chile'], ['0', 'Competidores en Chile']].map(([n, l], i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 'clamp(24px,3.5vw,36px)', fontWeight: 800, color: '#17d4a0' }}>{n}</div>
                <div style={{ fontSize: 13, color: '#7795ad', marginTop: 4, maxWidth: 110 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ padding: '70px 5vw', background: '#0c1a2e' }}>
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 50 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#17d4a0', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Cómo funciona</div>
            <h2 style={{ fontSize: 'clamp(26px,4vw,40px)', fontWeight: 700 }}>De acuerdo informal a contrato protegido</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(230px,1fr))', gap: 18 }}>
            {[
              ['🔍', '01', 'Descubre y conecta', 'La IA cruza marcas con eventos según audiencia, presupuesto y valores. Sin agencias ni comisiones ocultas.'],
              ['📝', '02', 'Contrata con escrow', 'Generas el contrato con hitos. La marca deposita y el dinero queda retenido hasta verificar cada entrega.'],
              ['⚖️', '03', 'Arbitraje con IA', 'Si hay conflicto, ambas partes tienen 7 días para presentar evidencia y la IA decide qué % se libera.'],
              ['⭐', '04', 'Construye reputación', 'Tu tasa de cumplimiento crece con cada acuerdo verificado y te diferencia en el marketplace.'],
            ].map(([icon, num, title, desc], i) => (
              <div key={i} className="card card-hover" style={{ position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: -8, right: 8, fontSize: 56, fontWeight: 800, fontFamily: 'Sora,sans-serif', color: 'rgba(23,212,160,.05)' }}>{num}</div>
                <div style={{ fontSize: 32, marginBottom: 14 }}>{icon}</div>
                <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 8 }}>{title}</h3>
                <p style={{ fontSize: 14, color: '#7795ad', lineHeight: 1.6 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOUNDER */}
      <section style={{ padding: '70px 5vw' }}>
        <div style={{ maxWidth: 740, margin: '0 auto', textAlign: 'center' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#17d4a0', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>El fundador</div>
          <div className="card" style={{ padding: 34, border: '1px solid rgba(23,212,160,.15)', textAlign: 'left', display: 'flex', gap: 24, flexWrap: 'wrap', alignItems: 'flex-start' }}>
            <div style={{ width: 80, height: 80, borderRadius: 18, background: 'linear-gradient(135deg,#17d4a0,#0d9d76)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Sora,sans-serif', fontSize: 26, fontWeight: 800, color: '#08111f', flexShrink: 0 }}>CT</div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div style={{ fontWeight: 700, fontSize: 20, marginBottom: 4 }}>Cristóbal Torretti</div>
              <div style={{ fontSize: 14, color: '#17d4a0', fontWeight: 600, marginBottom: 16 }}>Founder & CFO · Chile 🇨🇱</div>
              <p style={{ fontSize: 14, color: '#7795ad', lineHeight: 1.75 }}>
                "GetSponzo nació de una frustración personal. Organizaba eventos deportivos en Chile y cada vez que intentaba conseguir una marca patrocinadora, me enfrentaba al mismo muro: sin contactos en agencias no existías, y si llegabas a una marca por tu cuenta, el proceso era lento, informal y sin ninguna garantía.
                <br /><br />
                Vi que el problema no era solo mío — era de miles de organizadores, clubes y creadores que tienen audiencias reales pero no tienen acceso al mundo del patrocinio. Decidí construir la herramienta que yo mismo necesitaba.
                <br /><br />
                Las oportunidades no deberían depender de a quién conoces, sino del valor que eres capaz de crear. Eso es GetSponzo."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section style={{ padding: '70px 5vw', background: '#0c1a2e' }}>
        <div style={{ maxWidth: 1020, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#17d4a0', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Precios simples</div>
            <h2 style={{ fontSize: 'clamp(26px,4vw,40px)', fontWeight: 700 }}>Solo cobramos cuando cierras</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(250px,1fr))', gap: 18 }}>
            {[
              { name: 'Básico', price: '€0', note: '6% por acuerdo cerrado', featured: false, feats: ['Perfil verificado', 'Matches con IA', 'Chat seguro', 'Contratos automáticos', 'Escrow incluido'] },
              { name: 'Premium', price: '€90', note: 'Solo 3% por acuerdo', featured: true, feats: ['Todo lo de Básico', 'Matches prioritarios', 'Analytics de ROI', 'Disputas prioritarias', 'Badge Top Patrocinado'] },
              { name: 'Agencias', price: '€300', note: 'Solo 3% por acuerdo', featured: false, feats: ['Todo lo de Premium', 'Dashboard multi-cliente', 'API de integración', 'Account manager'] },
            ].map((plan, i) => (
              <div key={i} className="card" style={{
                padding: 28, position: 'relative',
                border: plan.featured ? '1.5px solid #17d4a0' : '1px solid rgba(255,255,255,0.07)',
                background: plan.featured ? 'linear-gradient(180deg,rgba(23,212,160,.06),rgba(15,34,54,1))' : '#0f2236',
              }}>
                {plan.featured && (
                  <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: '#17d4a0', color: '#08111f', fontSize: 11, fontWeight: 800, padding: '4px 14px', borderRadius: 99, textTransform: 'uppercase', letterSpacing: .5, whiteSpace: 'nowrap' }}>
                    Más popular
                  </div>
                )}
                <div style={{ fontSize: 14, fontWeight: 700, color: '#7795ad', marginBottom: 8 }}>{plan.name}</div>
                <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 40, fontWeight: 800, marginBottom: 4 }}>{plan.price}<span style={{ fontSize: 16, color: '#7795ad', fontWeight: 400 }}>{plan.price !== '€0' ? '/mes' : ''}</span></div>
                <div style={{ fontSize: 13, color: '#17d4a0', fontWeight: 600, marginBottom: 22 }}>{plan.note}</div>
                {plan.feats.map((f, j) => (
                  <div key={j} style={{ display: 'flex', gap: 9, alignItems: 'center', marginBottom: 11, fontSize: 14 }}>
                    <span style={{ color: '#17d4a0', fontWeight: 700 }}>✓</span><span>{f}</span>
                  </div>
                ))}
                <button onClick={() => navigate('/platform')} className={plan.featured ? 'btn-primary' : 'btn-ghost'} style={{ width: '100%', justifyContent: 'center', marginTop: 20, padding: 12 }}>
                  Empezar
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 5vw', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 60% 80% at 50% 100%,rgba(23,212,160,.1),transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ position: 'relative', maxWidth: 600, margin: '0 auto' }}>
          <h2 style={{ fontSize: 'clamp(26px,4vw,42px)', fontWeight: 800, marginBottom: 16 }}>¿Listo para verlo en acción?</h2>
          <p style={{ fontSize: 16, color: '#7795ad', marginBottom: 30 }}>Explora la plataforma completa con escrow, árbitro IA y reputación verificada.</p>
          <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => navigate('/platform')} className="btn-primary" style={{ fontSize: 16, padding: '14px 32px' }}>Abrir la plataforma →</button>
            <button onClick={() => setInvestOpen(true)} className="btn-ghost" style={{ fontSize: 16, padding: '14px 32px' }}>Quiero invertir</button>
          </div>
        </div>
      </section>

      <footer style={{ padding: '28px 5vw', borderTop: '1px solid rgba(255,255,255,0.07)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Logo size={26} glow={false} />
          <span style={{ fontFamily: 'Sora,sans-serif', fontWeight: 800, fontSize: 16 }}>Get<span style={{ color: '#17d4a0' }}>Sponzo</span></span>
        </div>
        <div style={{ fontSize: 13, color: '#54708a' }}>getsponzo.com · {new Date().getFullYear()}</div>
      </footer>

      {investOpen && <InvestModal close={() => setInvestOpen(false)} showToast={showToast} />}
    </div>
  )
}
