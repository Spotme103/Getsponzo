import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Landing from './pages/Landing'
import Platform from './pages/Platform'
import ApiKeySetup from './components/ApiKeySetup'
import Toast from './components/Toast'

export default function App() {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_api_key') || '')
  const [toast, setToast] = useState(null)

  const showToast = (msg, icon = '✓', sub = '') => {
    setToast({ msg, icon, sub })
    setTimeout(() => setToast(null), 3200)
  }

  const saveApiKey = (key) => {
    localStorage.setItem('gemini_api_key', key)
    setApiKey(key)
    showToast('API Key guardada', '🔑', 'El árbitro IA está listo.')
  }

  return (
    <Router basename="/getsponzo">
      <Routes>
        <Route path="/" element={<Landing showToast={showToast} />} />
        <Route
          path="/platform/*"
          element={
            apiKey
              ? <Platform apiKey={apiKey} showToast={showToast} onClearKey={() => { localStorage.removeItem('gemini_api_key'); setApiKey('') }} />
              : <ApiKeySetup onSave={saveApiKey} />
          }
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      {toast && <Toast {...toast} />}
    </Router>
  )
}
