import React from 'react'

export default function Profile({ showToast, onClearKey }) {
  const metrics = [
    ['Cumplimiento de hitos', 97],
    ['Velocidad de respuesta', 88],
    ['Satisfacción de patrocinadores', 94],
    ['Perfil completado', 100],
  ]

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Mi perfil</h2>
        <p style={{ fontSize: 14, color: '#7795ad' }}>Tu reputación verificada en GetSponzo.</p>
      </div>

      <div className="card" style={{ padding: 26, marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center', marginBottom: 24, flexWrap: 'wrap' }}>
          <div style={{ width: 66, height: 66, borderRadius: 18, background: 'linear-gradient(135deg,#17d4a0,#0d9d76)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30 }}>⚽</div>
          <div style={{ flex: 1, minWidth: 140 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 5 }}>
              <h2 style={{ fontSize: 20, fontWeight: 700 }}>Club Deportivo Andes</h2>
              <span className="tag" style={{ background: 'rgba(240,198,74,.1)', color: '#f0c64a' }}>🏆 Top Patrocinado</span>
            </div>
            <div style={{ fontSize: 13, color: '#7795ad' }}>Deporte · Santiago, Chile</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(110px,1fr))', gap: 12, marginBottom: 24 }}>
          {[['96', 'Trust score', '#17d4a0'], ['8', 'Acuerdos ✓', '#f4f9fc'], ['97%', 'Cumplimiento', '#2ecf7f'], ['4.8 ★', 'Valoración', '#f0c64a']].map(([v, l, c], i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,.03)', borderRadius: 13, padding: 16, textAlign: 'center' }}>
              <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 24, fontWeight: 800, color: c }}>{v}</div>
              <div style={{ fontSize: 11, color: '#7795ad', marginTop: 3 }}>{l}</div>
            </div>
          ))}
        </div>

        <div style={{ background: 'rgba(255,255,255,.02)', borderRadius: 14, padding: 18, marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Métricas de reputación</div>
          {metrics.map(([l, v], i) => (
            <div key={i} style={{ marginBottom: 13 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                <span style={{ color: '#7795ad' }}>{l}</span>
                <span style={{ fontWeight: 700, color: '#17d4a0' }}>{v}%</span>
              </div>
              <div style={{ height: 7, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden' }}>
                <div className="bar-fill" style={{ '--w': v + '%', width: v + '%' }} />
              </div>
            </div>
          ))}
        </div>

        <div style={{ background: 'rgba(23,212,160,.05)', border: '1px solid rgba(23,212,160,.15)', borderRadius: 13, padding: '12px 16px', marginBottom: 16, fontSize: 13, color: '#17d4a0' }}>
          ✅ Árbitro IA (Gemini) conectado · Cláusula de arbitraje aceptada
        </div>

        <button onClick={() => { onClearKey(); showToast('API Key eliminada', '🔑', 'Vuelve a configurarla cuando quieras.') }} style={{ background: 'rgba(240,101,74,.06)', color: '#f0654a', border: '1px solid rgba(240,101,74,.2)', borderRadius: 11, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
          🔑 Cambiar API Key de Gemini
        </button>
      </div>
    </div>
  )
}
