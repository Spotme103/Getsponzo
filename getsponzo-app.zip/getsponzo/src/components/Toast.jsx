import React from 'react'

export default function Toast({ msg, icon, sub }) {
  return (
    <div style={{
      position: 'fixed', bottom: 26, left: '50%', transform: 'translateX(-50%)',
      zIndex: 9999, background: '#13283f', border: '1px solid rgba(23,212,160,0.2)',
      borderRadius: 14, padding: '14px 20px', display: 'flex', alignItems: 'center',
      gap: 12, boxShadow: '0 16px 50px rgba(0,0,0,.5)', maxWidth: 380,
      animation: 'fadeUp .3s ease both',
    }}>
      <span style={{ fontSize: 20 }}>{icon}</span>
      <div>
        <div style={{ fontWeight: 700, fontSize: 14 }}>{msg}</div>
        {sub && <div style={{ fontSize: 12, color: '#7795ad', marginTop: 2 }}>{sub}</div>}
      </div>
    </div>
  )
}
