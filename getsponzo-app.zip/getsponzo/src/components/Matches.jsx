import React from 'react'

const MATCHES = [
  { id: 1, name: 'Club Deportivo Andes', icon: '⚽', cat: 'Deporte', budget: '€4.000–€8.000', match: 94, reason: 'Audiencia familiar alineada con tus valores de marca' },
  { id: 2, name: 'Festival Sonidos del Sur', icon: '🎵', cat: 'Música', budget: '€10.000–€18.000', match: 89, reason: 'Alta visibilidad digital + público joven premium' },
  { id: 3, name: 'Podcast Mente Emprendedora', icon: '🎙️', cat: 'Podcast', budget: '€1.500–€3.500', match: 86, reason: 'Audiencia B2B de alto poder adquisitivo en LATAM' },
]

export default function Matches({ showToast, goTo }) {
  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Tus matches</h2>
        <p style={{ fontSize: 14, color: '#7795ad' }}>La IA seleccionó estas oportunidades según tu audiencia, presupuesto y valores.</p>
      </div>

      <div style={{ background: 'rgba(23,212,160,.04)', border: '1px solid rgba(23,212,160,.15)', borderRadius: 14, padding: '14px 18px', marginBottom: 20, display: 'flex', gap: 12, alignItems: 'center' }}>
        <span style={{ fontSize: 22 }}>🤖</span>
        <div style={{ fontSize: 13, color: '#7795ad', lineHeight: 1.5 }}>
          El algoritmo de matches analiza <strong style={{ color: '#f4f9fc' }}>audiencia, presupuesto, valores ESG y historial</strong> para sugerirte las oportunidades con más probabilidad de éxito.
        </div>
      </div>

      {MATCHES.map(m => (
        <div key={m.id} className="card card-hover" style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap', marginBottom: 12 }}
          onClick={() => { showToast('Abriendo detalle', '🔍'); goTo('explore') }}>
          <div style={{ width: 50, height: 50, borderRadius: 14, background: 'rgba(23,212,160,.1)', border: '1px solid rgba(23,212,160,.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26 }}>{m.icon}</div>
          <div style={{ flex: 1, minWidth: 140 }}>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{m.name}</div>
            <div style={{ fontSize: 13, color: '#7795ad', marginBottom: 4 }}>{m.cat} · {m.budget}</div>
            <div style={{ fontSize: 12, color: '#17d4a0' }}>✓ {m.reason}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 26, fontWeight: 800, color: '#17d4a0' }}>{m.match}%</div>
            <div style={{ fontSize: 11, color: '#7795ad' }}>match IA</div>
          </div>
        </div>
      ))}
    </div>
  )
}
