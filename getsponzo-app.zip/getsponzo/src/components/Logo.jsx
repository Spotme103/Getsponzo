import React from 'react'

export default function Logo({ size = 38, glow = true }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80"
      style={glow ? { animation: 'glow 4s ease-in-out infinite' } : {}}>
      <defs>
        <filter id="lgw">
          <feGaussianBlur stdDeviation="1" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3df0bd" />
          <stop offset="1" stopColor="#0d9d76" />
        </linearGradient>
      </defs>
      <g stroke="url(#lg)" strokeWidth="1" strokeOpacity="0.5" fill="none" filter="url(#lgw)">
        <line x1="40" y1="8" x2="58" y2="26" /><line x1="58" y1="26" x2="72" y2="40" />
        <line x1="72" y1="40" x2="58" y2="54" /><line x1="58" y1="54" x2="40" y2="72" />
        <line x1="40" y1="72" x2="22" y2="54" /><line x1="22" y1="54" x2="8" y2="40" />
        <line x1="8" y1="40" x2="22" y2="26" /><line x1="22" y1="26" x2="40" y2="8" />
        <line x1="40" y1="8" x2="40" y2="72" /><line x1="8" y1="40" x2="72" y2="40" />
        <line x1="58" y1="26" x2="40" y2="40" /><line x1="40" y1="40" x2="22" y2="54" />
        <line x1="22" y1="26" x2="40" y2="40" /><line x1="40" y1="40" x2="58" y2="54" />
      </g>
      <g filter="url(#lgw)">
        <circle cx="40" cy="8" r="4" fill="#17d4a0" /><circle cx="40" cy="8" r="1.5" fill="#cffff0" />
        <circle cx="72" cy="40" r="4" fill="#17d4a0" /><circle cx="72" cy="40" r="1.5" fill="#cffff0" />
        <circle cx="40" cy="72" r="4" fill="#17d4a0" /><circle cx="40" cy="72" r="1.5" fill="#cffff0" />
        <circle cx="8" cy="40" r="4" fill="#17d4a0" /><circle cx="8" cy="40" r="1.5" fill="#cffff0" />
        <circle cx="58" cy="26" r="3" fill="#3df0bd" /><circle cx="58" cy="54" r="3" fill="#3df0bd" />
        <circle cx="22" cy="54" r="3" fill="#3df0bd" /><circle cx="22" cy="26" r="3" fill="#3df0bd" />
        <circle cx="40" cy="40" r="5" fill="#0d9d76" /><circle cx="40" cy="40" r="2.2" fill="#cffff0" />
      </g>
    </svg>
  )
}
