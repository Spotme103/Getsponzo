import React, { useState } from 'react'

const INIT_CONTRACTS = [
  {
    id: 'c1', n: 'Patrocinio Club Deportivo Andes', party: 'Tu Marca ↔ Club Andes',
    amount: 6000, paid: 4000, status: 'active',
    milestones: [
      { id: 1, title: 'Logo en camisetas', amount: 2000, status: 'approved' },
      { id: 2, title: 'Posts en redes sociales', amount: 2000, status: 'approved' },
      { id: 3, title: 'Vallas publicitarias en estadio', amount: 2000, status: 'disputed' },
    ],
  },
  {
    id: 'c2', n: 'Patrocinio Festival Sonidos del Sur', party: 'Tu Marca ↔ Festival',
    amount: 14000, paid: 14000, status: 'completed',
    milestones: [
      { id: 1, title: 'Banner principal escenario', amount: 5000, status: 'approved' },
      { id: 2, title: 'Mención en comunicados', amount: 3000, status: 'approved' },
      { id: 3, title: 'Activación zona VIP', amount: 4000, status: 'approved' },
      { id: 4, title: 'Informe de impacto', amount: 2000, status: 'approved' },
    ],
  },
]

export default function Contracts({ showToast, goTo }) {
  const [contracts, setContracts] = useState(INIT_CONTRACTS)
  const [sel, setSel] = useState(null)
  const [showNew, setShowNew] = useState(false)

  const approveMs = (cId, msId) => {
    setContracts(cs => cs.map(c => c.id !== cId ? c : {
      ...c,
      paid: c.paid + c.milestones.find(m => m.id === msId).amount,
      milestones: c.milestones.map(m => m.id === msId ? { ...m, status: 'approved' } : m),
    }))
    showToast('Hito aprobado', '✅', 'El pago fue liberado del escrow.')
  }

  if (sel) {
    const c = contracts.find(x => x.id === sel)
    return <ContractDetail c={c} back={() => setSel(null)} onApprove={(msId) => approveMs(c.id, msId)} showToast={showToast} goTo={goTo} />
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Contratos</h2>
          <p style={{ fontSize: 14, color: '#7795ad' }}>Gestiona tus acuerdos con pago protegido por hitos.</p>
        </div>
        <button onClick={() => setShowNew(true)} className="btn-primary" style={{ padding: '11px 20px' }}>+ Nuevo contrato</button>
      </div>

      {contracts.map(c => (
        <div key={c.id} onClick={() => setSel(c.id)} className="card card-hover" style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 3 }}>{c.n}</div>
              <div style={{ fontSize: 13, color: '#7795ad' }}>{c.party}</div>
            </div>
            <span className="tag" style={{
              background: c.status === 'completed' ? 'rgba(46,207,127,.09)' : c.milestones.some(m => m.status === 'disputed') ? 'rgba(240,101,74,.09)' : 'rgba(23,212,160,.1)',
              color: c.status === 'completed' ? '#2ecf7f' : c.milestones.some(m => m.status === 'disputed') ? '#f0654a' : '#17d4a0',
            }}>
              {c.status === 'completed' ? '✅ Completado' : c.milestones.some(m => m.status === 'disputed') ? '⚖️ Con disputa' : '🟢 Activo'}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 7 }}>
            <span style={{ color: '#7795ad' }}>Escrow liberado</span>
            <span style={{ fontWeight: 700 }}>€{c.paid.toLocaleString()} / €{c.amount.toLocaleString()}</span>
          </div>
          <div style={{ height: 8, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden', marginBottom: 10 }}>
            <div className="bar-fill" style={{ '--w': (c.paid / c.amount * 100) + '%', width: (c.paid / c.amount * 100) + '%' }} />
          </div>
          <div style={{ fontSize: 12, color: '#7795ad' }}>
            {c.milestones.filter(m => m.status === 'approved').length}/{c.milestones.length} hitos verificados
            {c.milestones.some(m => m.status === 'disputed') ? ' · 1 en disputa ⚖️' : ''}
          </div>
        </div>
      ))}

      {showNew && <NewContractModal close={() => setShowNew(false)} showToast={showToast} onCreate={(c) => { setContracts(cs => [...cs, c]); setShowNew(false) }} />}
    </div>
  )
}

function ContractDetail({ c, back, onApprove, showToast, goTo }) {
  return (
    <div>
      <button onClick={back} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#7795ad', marginBottom: 16, background: 'none', border: 'none', cursor: 'pointer' }}>← Volver a contratos</button>
      <div className="card" style={{ padding: 26 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>{c.n}</h2>
            <div style={{ fontSize: 13, color: '#7795ad' }}>{c.party}</div>
          </div>
          <span className="tag" style={{ background: c.status === 'completed' ? 'rgba(46,207,127,.09)' : 'rgba(23,212,160,.1)', color: c.status === 'completed' ? '#2ecf7f' : '#17d4a0' }}>
            {c.status === 'completed' ? '✅ Completado' : '🟢 Activo'}
          </span>
        </div>

        {/* Escrow bar */}
        <div style={{ background: 'rgba(255,255,255,.03)', borderRadius: 14, padding: 18, marginBottom: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 9 }}>
            <span style={{ fontSize: 13, color: '#7795ad' }}>Escrow liberado</span>
            <span style={{ fontWeight: 700, fontSize: 15 }}>€{c.paid.toLocaleString()} / €{c.amount.toLocaleString()}</span>
          </div>
          <div style={{ height: 10, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden' }}>
            <div className="bar-fill" style={{ '--w': (c.paid / c.amount * 100) + '%', width: (c.paid / c.amount * 100) + '%' }} />
          </div>
        </div>

        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Hitos del contrato</div>
        {c.milestones.map(m => (
          <div key={m.id} style={{
            display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px',
            background: 'rgba(255,255,255,.02)', borderRadius: 13, marginBottom: 10,
            borderLeft: `3px solid ${m.status === 'approved' ? '#2ecf7f' : m.status === 'disputed' ? '#f0654a' : '#54708a'}`,
          }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: m.status === 'approved' ? 'rgba(46,207,127,.09)' : m.status === 'disputed' ? 'rgba(240,101,74,.09)' : 'rgba(255,255,255,.05)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
              {m.status === 'approved' ? '✓' : m.status === 'disputed' ? '⚖️' : '⏳'}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{m.title}</div>
              <div style={{ fontSize: 12, color: '#7795ad' }}>
                €{m.amount.toLocaleString()} · {m.status === 'approved' ? 'Liberado ✓' : m.status === 'disputed' ? 'En disputa — IA arbitrando' : 'Pendiente de verificación'}
              </div>
            </div>
            {m.status === 'pending' && <button onClick={() => onApprove(m.id)} className="btn-primary" style={{ padding: '8px 14px', fontSize: 12 }}>Aprobar</button>}
            {m.status === 'disputed' && <button onClick={() => goTo('disputes')} className="btn-danger" style={{ fontSize: 12 }}>Ver disputa</button>}
          </div>
        ))}
      </div>
    </div>
  )
}

function NewContractModal({ close, showToast, onCreate }) {
  const [f, setF] = useState({ sponsor: '', event: 'Club Deportivo Andes', amount: '6000', hitos: 'Hito 1: Logo en camisetas (€2.000)\nHito 2: Posts en redes (€2.000)\nHito 3: Vallas en estadio (€2.000)' })
  const [accepted, setAccepted] = useState(false)
  const [done, setDone] = useState(false)

  const create = () => {
    if (!f.sponsor) { showToast('Indica el patrocinador', 'ℹ️'); return }
    if (!accepted) { showToast('Acepta la cláusula IA', '⚖️'); return }
    const newC = {
      id: 'c' + Date.now(), n: `Patrocinio ${f.event}`, party: `${f.sponsor} ↔ ${f.event}`,
      amount: Number(f.amount), paid: 0, status: 'active',
      milestones: f.hitos.split('\n').filter(Boolean).map((h, i) => {
        const match = h.match(/€([\d.]+)/)
        const amount = match ? Number(match[1].replace('.', '')) : Math.round(Number(f.amount) / 3)
        return { id: i + 1, title: h.replace(/\(€[\d.]+\)/, '').replace(/Hito \d+: /, '').trim(), amount, status: 'pending' }
      }),
    }
    onCreate(newC)
    showToast('Contrato creado', '🔒', `€${Number(f.amount).toLocaleString()} retenidos en escrow.`)
  }

  return (
    <div onClick={e => { if (e.target === e.currentTarget) close() }} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.85)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 18, overflowY: 'auto' }}>
      <div className="glass" style={{ borderRadius: 20, padding: 28, maxWidth: 520, width: '100%', border: '1px solid rgba(23,212,160,.15)', maxHeight: '92vh', overflowY: 'auto', position: 'relative' }}>
        <button onClick={close} style={{ position: 'absolute', top: 16, right: 18, fontSize: 20, color: '#7795ad', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button>
        {!done ? (
          <>
            <h3 style={{ fontSize: 21, fontWeight: 700, marginBottom: 6 }}>Nuevo contrato con escrow</h3>
            <p style={{ fontSize: 13, color: '#7795ad', marginBottom: 20 }}>El dinero queda protegido hasta verificar cada hito.</p>
            <div style={{ marginBottom: 13 }}><label className="lbl">Patrocinador (marca)</label><input className="inp" placeholder="Nombre de la marca" value={f.sponsor} onChange={e => setF({ ...f, sponsor: e.target.value })} /></div>
            <div style={{ marginBottom: 13 }}><label className="lbl">Patrocinado</label><input className="inp" value={f.event} onChange={e => setF({ ...f, event: e.target.value })} /></div>
            <div style={{ marginBottom: 13 }}><label className="lbl">Importe total (€)</label><input className="inp" type="number" value={f.amount} onChange={e => setF({ ...f, amount: e.target.value })} /></div>
            <div style={{ marginBottom: 18 }}><label className="lbl">Hitos y contraprestaciones</label><textarea className="inp" style={{ minHeight: 90, resize: 'vertical' }} value={f.hitos} onChange={e => setF({ ...f, hitos: e.target.value })} /></div>
            <div onClick={() => setAccepted(!accepted)} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: '14px 16px', background: 'rgba(124,58,237,.08)', border: `1px solid ${accepted ? 'rgba(124,58,237,.5)' : 'rgba(124,58,237,.2)'}`, borderRadius: 13, marginBottom: 18, cursor: 'pointer' }}>
              <div style={{ width: 22, height: 22, borderRadius: 6, border: '2px solid #a78bfa', background: accepted ? '#a78bfa' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{accepted && <span style={{ color: '#fff', fontSize: 13, fontWeight: 700 }}>✓</span>}</div>
              <div style={{ fontSize: 13, color: '#a78bfa', lineHeight: 1.5 }}><strong>Acepto la Cláusula de Arbitraje IA.</strong> Si hay disputa, ambas partes tienen 7 días para presentar evidencia y la IA decide qué % del pago se libera. El veredicto es vinculante.</div>
            </div>
            <button onClick={() => { create(); setDone(true) }} className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 13 }}>🔒 Generar contrato con escrow</button>
          </>
        ) : (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 14 }}>✅</div>
            <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 10 }}>¡Contrato activado!</h3>
            <p style={{ fontSize: 14, color: '#7795ad', marginBottom: 20 }}>€{Number(f.amount).toLocaleString()} retenidos en escrow. Se liberarán hito a hito cuando el patrocinado presente evidencia verificable.</p>
            <button onClick={close} className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 13 }}>Ver mis contratos</button>
          </div>
        )}
      </div>
    </div>
  )
}
