import React, { useState, useRef, useEffect } from 'react'

const INIT_MSGS = [
  { id: 1, me: false, text: 'Hola, vimos su perfil y nos interesa patrocinar el próximo torneo regional. ¿Podemos coordinar los detalles?', time: '10:24' },
  { id: 2, me: true, text: '¡Hola! Claro, encantados. Tenemos paquetes desde €4.000 con visibilidad en camiseta y vallas. Te comparto la propuesta por aquí.', time: '10:31' },
  { id: 3, me: false, text: 'Perfecto. ¿Qué incluye el paquete básico exactamente?', time: '10:35' },
]

const CONTACTS = [
  { id: 1, name: 'Club Deportivo Andes', icon: '⚽', lastMsg: '¿Qué incluye el paquete básico?', time: '10:35', unread: 1 },
  { id: 2, name: 'Festival Sonidos del Sur', icon: '🎵', lastMsg: 'Gracias por el informe de impacto', time: 'Ayer', unread: 0 },
]

export default function Messages({ showToast }) {
  const [msgs, setMsgs] = useState(INIT_MSGS)
  const [txt, setTxt] = useState('')
  const [selContact, setSelContact] = useState(1)
  const endRef = useRef(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])

  const send = () => {
    if (!txt.trim()) return
    const hasContact = /@|(\+?\d[\d\s\-]{7,}\d)|(whatsapp|telegram|instagram|email)/i.test(txt)
    if (hasContact) {
      showToast('Mensaje bloqueado', '🚫', 'No compartas datos de contacto fuera de la plataforma.')
      setTxt('')
      return
    }
    setMsgs(m => [...m, { id: Date.now(), me: true, text: txt, time: new Date().toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }) }])
    setTxt('')
  }

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Mensajes</h2>
        <p style={{ fontSize: 14, color: '#7795ad' }}>Comunicación segura. Compartir datos de contacto está bloqueado.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 14, height: 480 }}>
        {/* Contact list */}
        <div className="card" style={{ padding: 12, overflowY: 'auto' }}>
          {CONTACTS.map(c => (
            <div key={c.id} onClick={() => setSelContact(c.id)} style={{ padding: '12px 10px', borderRadius: 11, cursor: 'pointer', marginBottom: 4, background: selContact === c.id ? 'rgba(23,212,160,.08)' : 'transparent', border: selContact === c.id ? '1px solid rgba(23,212,160,.15)' : '1px solid transparent' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 38, height: 38, borderRadius: 11, background: 'rgba(23,212,160,.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>{c.icon}</div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: '#7795ad', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.lastMsg}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Chat */}
        <div className="card" style={{ padding: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid rgba(255,255,255,.06)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(23,212,160,.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>⚽</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>Club Deportivo Andes</div>
              <div style={{ fontSize: 11, color: '#2ecf7f' }}>● Comunicación segura</div>
            </div>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {msgs.map(m => (
              <div key={m.id} style={{ alignSelf: m.me ? 'flex-end' : 'flex-start', maxWidth: '75%' }}>
                <div style={{ padding: '11px 15px', borderRadius: 14, fontSize: 14, lineHeight: 1.5, background: m.me ? 'linear-gradient(135deg,#17d4a0,#0d9d76)' : 'rgba(255,255,255,.05)', color: m.me ? '#08111f' : '#f4f9fc', fontWeight: m.me ? 600 : 400 }}>
                  {m.text}
                </div>
                <div style={{ fontSize: 10, color: '#54708a', marginTop: 4, textAlign: m.me ? 'right' : 'left' }}>{m.time}</div>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          <div style={{ padding: 14, borderTop: '1px solid rgba(255,255,255,.06)', display: 'flex', gap: 10 }}>
            <input value={txt} onChange={e => setTxt(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Escribe un mensaje…" className="inp" style={{ flex: 1 }} />
            <button onClick={send} className="btn-primary" style={{ padding: '11px 18px' }}>Enviar</button>
          </div>
        </div>
      </div>
      <p style={{ fontSize: 12, color: '#54708a', textAlign: 'center', marginTop: 10 }}>
        💡 Prueba escribir un email o teléfono — el sistema lo bloqueará automáticamente.
      </p>
    </div>
  )
}
