import React, { useState } from 'react'
import Logo from './Logo'

export default function ApiKeySetup({ onSave }) {
  const [key, setKey] = useState('')
  const [show, setShow] = useState(false)

  return (
    <div style={{
      minHeight: '100vh', background: '#08111f', display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: 20,
    }}>
      <div style={{
        background: '#0f2236', border: '1px solid rgba(23,212,160,0.15)',
        borderRadius: 22, padding: 36, maxWidth: 480, width: '100%',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
          <Logo size={40} />
          <span style={{ fontFamily: 'Sora,sans-serif', fontWeight: 800, fontSize: 22 }}>
            Get<span style={{ color: '#17d4a0' }}>Sponzo</span>
          </span>
        </div>

        <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 10 }}>
          Conecta el árbitro IA
        </h2>
        <p style={{ fontSize: 14, color: '#7795ad', marginBottom: 24, lineHeight: 1.6 }}>
          GetSponzo usa Google Gemini para arbitrar disputas entre marcas y eventos.
          Necesitas una API Key gratuita de Google AI Studio.
        </p>

        <div style={{
          background: 'rgba(23,212,160,0.06)', border: '1px solid rgba(23,212,160,0.15)',
          borderRadius: 13, padding: '14px 16px', marginBottom: 24,
        }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: '#17d4a0', marginBottom: 8 }}>
            🔑 Cómo obtener tu API Key gratis:
          </div>
          {[
            ['1.', 'Ve a', 'aistudio.google.com', 'https://aistudio.google.com'],
            ['2.', 'Inicia sesión con tu cuenta Google', '', ''],
            ['3.', 'Haz clic en "Get API Key" → "Create API Key"', '', ''],
            ['4.', 'Copia la key y pégala aquí abajo', '', ''],
          ].map(([n, t, link, href], i) => (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, fontSize: 13 }}>
              <span style={{ color: '#17d4a0', fontWeight: 700, flexShrink: 0 }}>{n}</span>
              <span style={{ color: '#7795ad' }}>
                {t}{' '}
                {href && <a href={href} target="_blank" rel="noreferrer"
                  style={{ color: '#17d4a0', textDecoration: 'none', fontWeight: 600 }}>{link}</a>}
              </span>
            </div>
          ))}
        </div>

        <label className="lbl">Tu API Key de Google Gemini</label>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <input
            className="inp"
            type={show ? 'text' : 'password'}
            value={key}
            onChange={e => setKey(e.target.value)}
            placeholder="AIzaSy..."
            style={{ paddingRight: 44 }}
          />
          <button onClick={() => setShow(!show)} style={{
            position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
            color: '#7795ad', fontSize: 13,
          }}>{show ? '🙈' : '👁️'}</button>
        </div>

        <button
          className="btn-primary"
          style={{ width: '100%', justifyContent: 'center', padding: 13, fontSize: 15 }}
          onClick={() => { if (key.trim().length > 10) onSave(key.trim()) }}
        >
          🚀 Activar árbitro IA y entrar a la plataforma
        </button>

        <p style={{ fontSize: 11, color: '#54708a', textAlign: 'center', marginTop: 14 }}>
          Tu API Key se guarda solo en tu navegador. Nadie más puede verla.
        </p>
      </div>
    </div>
  )
}
