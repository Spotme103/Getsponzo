import React, { useState } from 'react'

export default function InvestModal({ close, showToast }) {
  const [tab, setTab] = useState('opportunity')
  const [f, setF] = useState({ name: '', email: '', msg: '' })

  const submit = () => {
    if (!f.email) { showToast('Indica tu email', 'ℹ️'); return }
    close()
    showToast('¡Gracias por tu interés!', '🚀', 'Cristóbal te contactará pronto.')
  }

  return (
    <div onClick={e => { if (e.target === e.currentTarget) close() }} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.85)', zIndex: 3000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 18, overflowY: 'auto' }}>
      <div className="glass" style={{ borderRadius: 20, padding: 28, maxWidth: 500, width: '100%', border: '1px solid rgba(23,212,160,.15)', maxHeight: '92vh', overflowY: 'auto', position: 'relative' }}>
        <button onClick={close} style={{ position: 'absolute', top: 16, right: 18, fontSize: 20, color: '#7795ad', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button>
        <h3 style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>Invierte en GetSponzo</h3>
        <p style={{ fontSize: 13, color: '#7795ad', marginBottom: 20 }}>Mercado de €1.967M en España · +19% anual · Pre-seed abierta</p>

        <div style={{ display: 'flex', gap: 8, marginBottom: 22 }}>
          {[['opportunity', 'La oportunidad'], ['contact', 'Contacto']].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ flex: 1, padding: 10, borderRadius: 11, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: tab === id ? '#17d4a0' : 'rgba(255,255,255,.05)', color: tab === id ? '#08111f' : '#7795ad' }}>{l}</button>
          ))}
        </div>

        {tab === 'opportunity' ? (
          <div>
            {[['🌱', 'Pre-seed', '€80.000', 'Prototipo + validación Chile + primeros usuarios'],
              ['🚀', 'Seed', '€200.000', 'Escalar Chile + lanzar España + primer equipo'],
              ['💎', 'Series A', '€347.000', 'Expansión LATAM + equipo completo']].map(([ic, t, amt, d], i) => (
              <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '14px 16px', background: 'rgba(255,255,255,.03)', borderRadius: 13, marginBottom: 10 }}>
                <span style={{ fontSize: 26 }}>{ic}</span>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{t} · <span style={{ color: '#17d4a0' }}>{amt}</span></div>
                  <div style={{ fontSize: 12, color: '#7795ad', marginTop: 2 }}>{d}</div>
                </div>
              </div>
            ))}
            <div style={{ background: 'rgba(23,212,160,.06)', border: '1px solid rgba(23,212,160,.15)', borderRadius: 13, padding: 16, marginTop: 6, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, textAlign: 'center' }}>
              {[['TIR', '54.5%'], ['VAN', '€684K'], ['Break-even', 'Año 3']].map(([l, v], i) => (
                <div key={i}>
                  <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 20, fontWeight: 800, color: '#17d4a0' }}>{v}</div>
                  <div style={{ fontSize: 11, color: '#7795ad' }}>{l}</div>
                </div>
              ))}
            </div>
            <button onClick={() => setTab('contact')} className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 12, marginTop: 16 }}>
              Me interesa — contactar →
            </button>
          </div>
        ) : (
          <div>
            <div style={{ marginBottom: 13 }}><label className="lbl">Tu nombre</label><input className="inp" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} placeholder="Nombre completo" /></div>
            <div style={{ marginBottom: 13 }}><label className="lbl">Tu email</label><input className="inp" type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} placeholder="tu@email.com" /></div>
            <div style={{ marginBottom: 18 }}><label className="lbl">Mensaje</label><textarea className="inp" style={{ minHeight: 80, resize: 'vertical' }} value={f.msg} onChange={e => setF({ ...f, msg: e.target.value })} placeholder="Cuéntanos tu interés y monto aproximado..." /></div>
            <button onClick={submit} className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 13 }}>
              📩 Enviar solicitud de inversión
            </button>
            <p style={{ fontSize: 11, color: '#54708a', textAlign: 'center', marginTop: 12 }}>Cristóbal Torretti · ctorretti@miuandes.cl · getsponzo.com</p>
          </div>
        )}
      </div>
    </div>
  )
}
