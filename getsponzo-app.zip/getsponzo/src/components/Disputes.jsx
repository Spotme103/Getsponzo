import React, { useState } from 'react'
import { callGeminiArbitration } from '../hooks/useGemini'

const INIT_DISPUTE = {
  id: 'd1', contract: 'c1',
  title: 'Hito 3 — Vallas publicitarias no instaladas en fecha',
  openedBy: 'Marca Patrocinadora', against: 'Club Deportivo Andes',
  status: 'under_review', priority: 'high', amount: 2000,
  description: 'El hito 3 establecía la instalación de 4 vallas publicitarias antes del 15 de marzo. A la fecha solo se instalaron 2, y sin la visibilidad acordada en el contrato original.',
  claimantEvidence: 'Fotos del estadio del 16 de marzo mostrando solo 2 vallas instaladas de las 4 acordadas.',
  daysLeft: 5,
  timeline: [
    { actor: 'Marca Patrocinadora', date: '16 mar', action: 'Abrió la disputa por incumplimiento del hito 3.' },
    { actor: 'GetSponzo', date: '16 mar', action: 'Pago de €2.000 congelado automáticamente. Plazo de 7 días abierto para presentar evidencia.' },
  ],
}

export default function Disputes({ apiKey, showToast }) {
  const [dispute, setDispute] = useState(INIT_DISPUTE)
  const [sel, setSel] = useState(false)
  const [defense, setDefense] = useState('')
  const [defenseSent, setDefenseSent] = useState(false)
  const [aiRunning, setAiRunning] = useState(false)
  const [aiProgress, setAiProgress] = useState(0)
  const [aiStatus, setAiStatus] = useState('')
  const [verdict, setVerdict] = useState(null)
  const [error, setError] = useState('')

  const runAI = async () => {
    setAiRunning(true)
    setVerdict(null)
    setError('')
    setAiProgress(0)

    const steps = [
      [600, 20, 'Verificando evidencia del demandante...'],
      [1200, 45, 'Analizando defensa del acusado...'],
      [1900, 68, 'Evaluando nivel de cumplimiento del hito...'],
      [2600, 85, 'Consultando al árbitro IA (Gemini)...'],
    ]
    steps.forEach(([t, p, s]) => setTimeout(() => { setAiProgress(p); setAiStatus(s) }, t))

    try {
      const result = await callGeminiArbitration(apiKey, {
        title: dispute.title,
        description: dispute.description,
        claimantEvidence: dispute.claimantEvidence,
        defendantEvidence: defenseSent ? defense : '',
      })
      setAiProgress(100)
      setAiStatus('Veredicto emitido.')
      const released = Math.round(dispute.amount * result.verdict_pct / 100)
      const retained = dispute.amount - released
      setVerdict({ ...result, released, retained })
    } catch (err) {
      setError('Error al conectar con Gemini: ' + err.message)
    }
    setAiRunning(false)
  }

  const executeVerdict = () => {
    setDispute(d => ({ ...d, status: 'resolved' }))
    showToast('Veredicto ejecutado', '⚡', `€${verdict.released.toLocaleString()} liberados · €${verdict.retained.toLocaleString()} devueltos.`)
    setSel(false)
    setVerdict(null)
    setDefenseSent(false)
    setDefense('')
  }

  if (sel) {
    return (
      <div>
        <button onClick={() => setSel(false)} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#7795ad', marginBottom: 16, background: 'none', border: 'none', cursor: 'pointer' }}>← Volver</button>

        {/* Header */}
        <div className="card" style={{ border: '1px solid rgba(240,101,74,.2)', padding: 24, marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#f0654a', textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 5 }}>⚖️ ARBITRAJE IA {verdict ? '· RESUELTO' : '· EN PROCESO'}</div>
              <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{dispute.title}</h2>
              <div style={{ fontSize: 13, color: '#7795ad' }}>Abierta por: {dispute.openedBy}</div>
            </div>
            {!verdict && (
              <div style={{ textAlign: 'center', background: 'rgba(240,198,74,.08)', border: '1px solid rgba(240,198,74,.2)', borderRadius: 13, padding: '10px 18px' }}>
                <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 28, fontWeight: 800, color: '#f0c64a' }}>{dispute.daysLeft}</div>
                <div style={{ fontSize: 11, color: '#7795ad' }}>días restantes</div>
              </div>
            )}
          </div>
          <div style={{ background: 'rgba(0,0,0,.2)', borderRadius: 11, padding: 14, fontSize: 13, color: '#7795ad', lineHeight: 1.6, marginBottom: 10 }}>{dispute.description}</div>
          <div style={{ fontSize: 12, color: '#f0c64a' }}>📎 Evidencia del demandante: {dispute.claimantEvidence}</div>
        </div>

        {/* Defense */}
        {!verdict && (
          <div className="card" style={{ border: '1px solid rgba(23,212,160,.15)', marginBottom: 14 }}>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 5 }}>📅 Ventana de defensa — {dispute.daysLeft} días restantes</div>
            <div style={{ fontSize: 13, color: '#7795ad', marginBottom: 14, lineHeight: 1.6 }}>Ambas partes tienen <strong style={{ color: '#f0c64a' }}>7 días</strong> para subir defensa y evidencias. La IA analizará todo al cerrar el plazo.</div>
            <div style={{ height: 8, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden', marginBottom: 16 }}>
              <div style={{ width: ((7 - dispute.daysLeft) / 7 * 100) + '%', height: '100%', background: 'linear-gradient(90deg,#f0c64a,#f0654a)', borderRadius: 99 }} />
            </div>
            {!defenseSent ? (
              <>
                <textarea className="inp" style={{ minHeight: 80, resize: 'vertical', marginBottom: 10 }} value={defense} onChange={e => setDefense(e.target.value)} placeholder="Explica tu posición y aporta evidencia..." />
                <button onClick={() => { if (!defense.trim()) { showToast('Escribe tu defensa', 'ℹ️'); return } setDefenseSent(true); showToast('Defensa registrada', '📎', 'La IA la considerará en el veredicto.') }} className="btn-ghost" style={{ width: '100%', justifyContent: 'center', padding: 12 }}>📎 Enviar mi defensa</button>
              </>
            ) : (
              <div style={{ background: 'rgba(46,207,127,.09)', border: '1px solid rgba(46,207,127,.2)', borderRadius: 11, padding: 13, fontSize: 13, color: '#2ecf7f' }}>✅ Defensa registrada. La IA la considerará en el veredicto.</div>
            )}
          </div>
        )}

        {/* AI Engine */}
        {!verdict && (
          <div className="card" style={{ border: '1px solid rgba(124,58,237,.3)', background: 'rgba(124,58,237,.04)', marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 10 }}>
              <span style={{ fontSize: 24 }}>🤖</span>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>Motor de Arbitraje IA — Gemini</div>
                <div style={{ fontSize: 12, color: '#7795ad' }}>Analiza evidencias y determina el % a liberar</div>
              </div>
            </div>
            {aiRunning ? (
              <div>
                <div style={{ fontSize: 13, color: '#7795ad', marginBottom: 10 }}>🔍 {aiStatus}</div>
                <div style={{ height: 10, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden', marginBottom: 8 }}>
                  <div style={{ width: aiProgress + '%', height: '100%', background: 'linear-gradient(90deg,#7c3aed,#a78bfa)', borderRadius: 99, transition: 'width .5s ease' }} />
                </div>
                <div style={{ fontSize: 12, color: '#a78bfa' }}>{aiProgress}% completado...</div>
              </div>
            ) : (
              <div>
                {error && <div style={{ background: 'rgba(240,101,74,.09)', border: '1px solid rgba(240,101,74,.2)', borderRadius: 10, padding: '10px 14px', fontSize: 13, color: '#f0654a', marginBottom: 14 }}>⚠️ {error}</div>}
                <div style={{ fontSize: 13, color: '#7795ad', marginBottom: 14, lineHeight: 1.6 }}>
                  Gemini analiza toda la evidencia aportada y emite un veredicto vinculante con el % exacto a liberar (0%, 25%, 50%, 75% o 100%). Según la cláusula aceptada al firmar el contrato.
                </div>
                <button onClick={runAI} style={{ background: 'rgba(124,58,237,.8)', color: '#fff', border: '1px solid rgba(124,58,237,.5)', borderRadius: 12, padding: '12px 20px', width: '100%', fontSize: 14, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                  🤖 Ejecutar arbitraje con Gemini
                </button>
              </div>
            )}
          </div>
        )}

        {/* Verdict */}
        {verdict && (
          <div style={{ background: 'rgba(124,58,237,.07)', border: '1.5px solid rgba(124,58,237,.4)', borderRadius: 18, padding: 24, animation: 'fadeUp .4s ease' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 18 }}>
              <span style={{ fontSize: 28 }}>🤖</span>
              <div>
                <div style={{ fontWeight: 800, fontSize: 19 }}>Veredicto de Gemini IA</div>
                <div style={{ fontSize: 12, color: '#a78bfa' }}>Arbitraje GetSponzo · Vinculante por contrato</div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
              <div style={{ background: 'rgba(46,207,127,.09)', border: '1px solid rgba(46,207,127,.2)', borderRadius: 13, padding: 16, textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: '#7795ad', marginBottom: 4 }}>LIBERADO AL PATROCINADO</div>
                <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 28, fontWeight: 800, color: '#2ecf7f' }}>€{verdict.released.toLocaleString()}</div>
                <div style={{ fontSize: 13, color: '#2ecf7f', fontWeight: 600 }}>{verdict.verdict_pct}%</div>
              </div>
              <div style={{ background: 'rgba(240,101,74,.09)', border: '1px solid rgba(240,101,74,.2)', borderRadius: 13, padding: 16, textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: '#7795ad', marginBottom: 4 }}>DEVUELTO AL PATROCINADOR</div>
                <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 28, fontWeight: 800, color: '#f0654a' }}>€{verdict.retained.toLocaleString()}</div>
                <div style={{ fontSize: 13, color: '#f0654a', fontWeight: 600 }}>{100 - verdict.verdict_pct}%</div>
              </div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#a78bfa', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '.5px' }}>Razonamiento de Gemini</div>
              {(verdict.reasoning || []).map((r, i) => (
                <div key={i} style={{ fontSize: 13, color: '#7795ad', lineHeight: 1.6, marginBottom: 6, paddingLeft: 12, borderLeft: '2px solid rgba(124,58,237,.3)' }}>{r}</div>
              ))}
            </div>
            <button onClick={executeVerdict} style={{ background: 'rgba(124,58,237,.8)', color: '#fff', border: '1px solid rgba(124,58,237,.5)', borderRadius: 12, padding: '13px 20px', width: '100%', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
              ✅ Confirmar y ejecutar veredicto
            </button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Centro de disputas</h2>
        <p style={{ fontSize: 14, color: '#7795ad' }}>Arbitraje vinculante por Gemini IA — 7 días de defensa para ambas partes.</p>
      </div>

      <div style={{ background: 'rgba(124,58,237,.04)', border: '1px solid rgba(23,212,160,.12)', borderRadius: 16, padding: 20, marginBottom: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14 }}>⚖️ Cómo funciona el arbitraje</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(80px,1fr))', gap: 12 }}>
          {[['📅', '7 días', 'Para subir evidencia'], ['🔒', 'Escrow', 'Pago congelado'], ['🤖', 'Gemini', 'Analiza sin sesgo'], ['📊', '% justo', '0, 25, 50, 75 o 100%'], ['✅', 'Vinculante', 'Por contrato']].map(([ic, t, d], i) => (
            <div key={i} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 22, marginBottom: 5 }}>{ic}</div>
              <div style={{ fontWeight: 700, fontSize: 12, marginBottom: 2 }}>{t}</div>
              <div style={{ fontSize: 11, color: '#7795ad' }}>{d}</div>
            </div>
          ))}
        </div>
      </div>

      <div onClick={() => dispute.status === 'under_review' && setSel(true)} className="card card-hover" style={{ borderLeft: '3px solid #f0654a' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 3 }}>{dispute.title}</div>
            <div style={{ fontSize: 12, color: '#7795ad', marginBottom: 4 }}>Abierta por: {dispute.openedBy}</div>
            {dispute.status === 'under_review' && <div style={{ fontSize: 12, color: '#f0c64a' }}>📅 {dispute.daysLeft} días para presentar defensa</div>}
            {dispute.status === 'resolved' && <div style={{ fontSize: 12, color: '#2ecf7f' }}>✅ Resuelta — veredicto ejecutado</div>}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
            <span className="tag" style={{ background: dispute.status === 'resolved' ? 'rgba(46,207,127,.09)' : 'rgba(124,58,237,.1)', color: dispute.status === 'resolved' ? '#2ecf7f' : '#a78bfa' }}>
              {dispute.status === 'resolved' ? '✅ Resuelta' : '🤖 Arbitraje en curso'}
            </span>
            <span className="tag" style={{ background: 'rgba(240,101,74,.09)', color: '#f0654a' }}>
              €{dispute.amount.toLocaleString()} en disputa
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
