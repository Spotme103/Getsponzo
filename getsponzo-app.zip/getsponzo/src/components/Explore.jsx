import React, { useState } from 'react'

const OPPS = [
  { id: 1, name: 'Club Deportivo Andes', cat: 'Deporte', icon: '⚽', loc: 'Santiago, Chile', budget: '€4.000–€8.000', match: 94, audience: 'Familias 25-45 · 12K asistentes/temporada', trust: 96, deals: 8, compliance: 97, badge: 'top', desc: 'Club de fútbol amateur con 12.000 asistentes por temporada. Buscamos patrocinador principal para camiseta y vallas publicitarias en el estadio.' },
  { id: 2, name: 'Festival Sonidos del Sur', cat: 'Música', icon: '🎵', loc: 'Valparaíso, Chile', budget: '€10.000–€18.000', match: 89, audience: 'Jóvenes 18-30 · 25K asistentes', trust: 91, deals: 5, compliance: 94, badge: 'verified', desc: 'Festival de música independiente con 25.000 asistentes. Fuerte presencia digital. Buscamos marcas alineadas con cultura joven y sostenibilidad.' },
  { id: 3, name: 'Podcast Mente Emprendedora', cat: 'Podcast', icon: '🎙️', loc: 'Remoto · LATAM', budget: '€1.500–€3.500', match: 86, audience: 'Profesionales 28-45 · 40K oyentes/ep', trust: 88, deals: 11, compliance: 92, badge: 'verified', desc: 'Podcast #3 de negocios en Chile. 40.000 oyentes por episodio. Audiencia de alto poder adquisitivo, ideal para marcas B2B y premium.' },
  { id: 4, name: 'Trail Running Cordillera', cat: 'Deporte', icon: '🏃', loc: 'Farellones, Chile', budget: '€3.000–€6.000', match: 82, audience: 'Deportistas 25-40 · 3K corredores', trust: 85, deals: 3, compliance: 90, badge: 'new', desc: 'Carrera de montaña anual con 3.000 corredores. Comunidad fitness premium. Ideal para marcas deportivas, wellness y tecnología.' },
]

const BADGES = {
  top: { label: '🏆 Top Patrocinado', bg: 'rgba(240,198,74,.1)', color: '#f0c64a' },
  verified: { label: '✅ Verificado', bg: 'rgba(46,207,127,.09)', color: '#2ecf7f' },
  new: { label: '🆕 Nuevo', bg: 'rgba(167,139,250,.1)', color: '#a78bfa' },
}

export default function Explore({ showToast, goTo }) {
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('Todas')
  const [sel, setSel] = useState(null)

  const filtered = OPPS.filter(o =>
    (cat === 'Todas' || o.cat === cat) &&
    (q === '' || o.name.toLowerCase().includes(q.toLowerCase()))
  )

  if (sel) return <OppDetail opp={sel} back={() => setSel(null)} showToast={showToast} goTo={goTo} />

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Explorar oportunidades</h2>
        <p style={{ fontSize: 14, color: '#7795ad' }}>Eventos, clubes y creadores verificados buscando patrocinio.</p>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 18, flexWrap: 'wrap' }}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar por nombre…" className="inp" style={{ flex: 1, minWidth: 180 }} />
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['Todas', 'Deporte', 'Música', 'Podcast'].map(c => (
            <button key={c} onClick={() => setCat(c)} style={{
              padding: '10px 15px', borderRadius: 10, fontSize: 13, fontWeight: 600, border: 'none',
              background: cat === c ? '#17d4a0' : 'rgba(255,255,255,.05)',
              color: cat === c ? '#08111f' : '#7795ad', cursor: 'pointer',
            }}>{c}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(270px,1fr))', gap: 14 }}>
        {filtered.map(o => {
          const b = BADGES[o.badge]
          return (
            <div key={o.id} onClick={() => setSel(o)} className="card card-hover">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                  <div style={{ width: 46, height: 46, borderRadius: 13, background: 'rgba(23,212,160,.1)', border: '1px solid rgba(23,212,160,.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>{o.icon}</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{o.name}</div>
                    <div style={{ fontSize: 12, color: '#7795ad' }}>{o.loc}</div>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 22, fontWeight: 800, color: '#17d4a0' }}>{o.match}%</div>
                  <div style={{ fontSize: 10, color: '#7795ad' }}>match IA</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 11, flexWrap: 'wrap' }}>
                <span className="tag" style={{ background: b.bg, color: b.color }}>{b.label}</span>
                <span className="tag" style={{ background: 'rgba(255,255,255,.05)', color: '#7795ad' }}>📊 {o.compliance}% cumple</span>
              </div>
              <div style={{ fontSize: 13, color: '#7795ad', marginBottom: 12, lineHeight: 1.5 }}>{o.audience}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 12, borderTop: '1px solid rgba(255,255,255,.06)' }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#17d4a0' }}>{o.budget}</span>
                <span style={{ fontSize: 12, color: '#7795ad' }}>{o.deals} acuerdos ✓</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function OppDetail({ opp, back, showToast, goTo }) {
  const b = BADGES[opp.badge]
  return (
    <div>
      <button onClick={back} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#7795ad', marginBottom: 16, background: 'none', border: 'none', cursor: 'pointer' }}>← Volver</button>
      <div className="card" style={{ padding: 28 }}>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center', marginBottom: 20, flexWrap: 'wrap' }}>
          <div style={{ width: 64, height: 64, borderRadius: 17, background: 'rgba(23,212,160,.1)', border: '1px solid rgba(23,212,160,.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>{opp.icon}</div>
          <div style={{ flex: 1, minWidth: 160 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 5 }}>
              <h2 style={{ fontSize: 22, fontWeight: 700 }}>{opp.name}</h2>
              <span className="tag" style={{ background: b.bg, color: b.color }}>{b.label}</span>
            </div>
            <div style={{ fontSize: 13, color: '#7795ad' }}>{opp.cat} · {opp.loc}</div>
          </div>
          <div style={{ textAlign: 'center', background: 'rgba(23,212,160,.08)', borderRadius: 14, padding: '12px 20px' }}>
            <div style={{ fontFamily: 'Sora,sans-serif', fontSize: 30, fontWeight: 800, color: '#17d4a0' }}>{opp.match}%</div>
            <div style={{ fontSize: 11, color: '#7795ad' }}>compatibilidad</div>
          </div>
        </div>
        <p style={{ fontSize: 15, color: '#7795ad', lineHeight: 1.7, marginBottom: 22 }}>{opp.desc}</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))', gap: 12, marginBottom: 24 }}>
          {[['Presupuesto', opp.budget, '#17d4a0'], ['Audiencia', opp.audience, '#f4f9fc'], ['Trust score', opp.trust + '/100', '#2ecf7f'], ['Acuerdos', opp.deals + ' completados', '#f4f9fc']].map(([l, v, c], i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,.03)', borderRadius: 13, padding: '14px 16px' }}>
              <div style={{ fontSize: 11, color: '#7795ad', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 5 }}>{l}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: c }}>{v}</div>
            </div>
          ))}
        </div>
        {/* Reputation bars */}
        <div style={{ background: 'rgba(255,255,255,.02)', borderRadius: 14, padding: 18, marginBottom: 22 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 14 }}>Reputación verificada</div>
          {[['Cumplimiento de hitos', opp.compliance], ['Velocidad de respuesta', 88], ['Satisfacción general', 94]].map(([l, v], i) => (
            <div key={i} style={{ marginBottom: 13 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
                <span style={{ color: '#7795ad' }}>{l}</span>
                <span style={{ fontWeight: 700, color: '#17d4a0' }}>{v}%</span>
              </div>
              <div style={{ height: 7, background: 'rgba(255,255,255,.05)', borderRadius: 99, overflow: 'hidden' }}>
                <div className="bar-fill" style={{ '--w': v + '%', width: v + '%' }} />
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <button onClick={() => { showToast('Contrato iniciado', '📝', 'Ve a Contratos para configurar los hitos.'); goTo('contracts') }} className="btn-primary" style={{ flex: 1, minWidth: 160, justifyContent: 'center', padding: 13 }}>
            📝 Crear contrato con escrow
          </button>
          <button onClick={() => { showToast('Chat abierto', '💬'); goTo('messages') }} className="btn-ghost" style={{ padding: 13 }}>
            💬 Contactar
          </button>
        </div>
      </div>
    </div>
  )
}
